# mylibrary/__init__.py

from .wsgi import create_app
